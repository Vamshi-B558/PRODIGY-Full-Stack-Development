package com.example.demoproject1loginpage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoProject1LoginpageApplicationTests {

    @Test
    void contextLoads() {
    }

}
